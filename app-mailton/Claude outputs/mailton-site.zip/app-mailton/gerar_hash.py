"""Gera as duas linhas secretas que vão no arquivo WSGI do PythonAnywhere.

Uso (no console Bash, dentro da pasta app-mailton):
    python3 gerar_hash.py

Ele pergunta a senha inicial do painel (não aparece na tela) e mostra o texto pronto para colar.
"""
import getpass
import secrets

from werkzeug.security import generate_password_hash

senha = getpass.getpass("Senha inicial do painel (mínimo 6 caracteres): ")
repetir = getpass.getpass("Digite de novo: ")
if senha != repetir:
    raise SystemExit("As senhas não são iguais. Rode de novo.")
if len(senha) < 6:
    raise SystemExit("A senha precisa ter pelo menos 6 caracteres. Rode de novo.")

print("\nCole estas duas linhas no arquivo WSGI (no lugar das linhas de exemplo):\n")
print(f"os.environ['WN_SECRET_KEY'] = '{secrets.token_hex(32)}'")
print(f"os.environ['WN_ADMIN_PASSWORD_HASH'] = '{generate_password_hash(senha)}'")
